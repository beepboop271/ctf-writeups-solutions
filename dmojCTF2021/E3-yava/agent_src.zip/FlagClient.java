public class FlagClient {
    private void flag() {
        // SECRET
    }
}
